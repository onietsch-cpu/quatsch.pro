# CE Translator – Heroku-Deployment-Anleitung

Diese Anleitung erklärt Schritt für Schritt, wie du die CE Translator App auf Heroku deployst.  
Sie ist so geschrieben, dass auch Nicht-Techniker sie verstehen.

---

## Was du brauchst

- Einen **Heroku-Account** (kostenlos unter https://signup.heroku.com)
- Die **Heroku CLI** (ein kleines Programm für den Terminal)
- **Git** (bereits auf deinem Computer, wenn du die App heruntergeladen hast)
- Einen **OpenAI API-Key** für die KI-Übersetzung (https://platform.openai.com/api-keys)
- Node.js 22 oder höher (https://nodejs.org)

---

## Schritt 1 – Heroku-Konto erstellen

1. Gehe zu https://signup.heroku.com
2. Fülle das Formular aus und klicke auf „Create free account"
3. Bestätige deine E-Mail-Adresse
4. Melde dich unter https://dashboard.heroku.com an

---

## Schritt 2 – Heroku CLI installieren

### macOS
```bash
brew tap heroku/brew && brew install heroku
```

### Windows
Lade den Installer herunter: https://devcenter.heroku.com/articles/heroku-cli

### Linux (Ubuntu/Debian)
```bash
curl https://cli-assets.heroku.com/install.sh | sh
```

### Anmeldung bestätigen
```bash
heroku login
```
→ Es öffnet sich der Browser. Melde dich mit deinem Heroku-Konto an.

---

## Schritt 3 – Git-Repository initialisieren (falls noch nicht vorhanden)

Öffne einen Terminal im Projektordner (`public_html`) und führe aus:

```bash
git init
git add .
git commit -m "Initial commit – CE Translator"
```

> **Hinweis:** Falls du bereits ein Git-Repository hast, überspringe diesen Schritt.

---

## Schritt 4 – Heroku-App erstellen

```bash
heroku create ce-translator
```

Wähle einen eindeutigen Namen (z.B. `ce-translator-meinnachname`).  
Heroku gibt dir dann eine URL wie: `https://ce-translator.herokuapp.com`

---

## Schritt 5 – Umgebungsvariablen setzen (wichtig!)

Diese Einstellungen werden auf Heroku als „Config Vars" gespeichert.  
Dein OpenAI API-Key und andere Geheimnisse werden niemals in den Code geschrieben.

```bash
# OpenAI API-Key für KI-Übersetzung
heroku config:set INTEGRATED_AI_API_KEY=sk-DEIN-OPENAI-KEY

# OpenAI API URL
heroku config:set INTEGRATED_AI_API_URL=https://api.openai.com/v1

# TTS-Modell (Sprachausgabe)
heroku config:set OPENAI_TTS_MODEL=tts-1

# App-URL (ersetze mit deiner tatsächlichen Heroku-URL)
heroku config:set CORS_ORIGIN=https://ce-translator.herokuapp.com

# Produktionsmodus aktivieren
heroku config:set NODE_ENV=production
```

### Alle Variablen prüfen
```bash
heroku config
```

---

## Schritt 6 – Node.js-Version festlegen

Füge in `apps/api/package.json` folgendes hinzu (falls noch nicht vorhanden):

```json
"engines": {
  "node": "22.x"
}
```

---

## Schritt 7 – Deployen

```bash
git add .
git commit -m "Heroku deployment setup"
git push heroku main
```

Heroku führt dann automatisch aus:
1. `npm install` – installiert alle Abhängigkeiten
2. `npm run heroku-postbuild` – baut das React-Frontend
3. Startet den Server über das `Procfile`

Der Build dauert 2–5 Minuten. Am Ende siehst du eine URL wie:
```
https://ce-translator.herokuapp.com
```

### App im Browser öffnen
```bash
heroku open
```

---

## Schritt 8 – Deployment testen

### 1. Health-Check
```bash
curl https://ce-translator.herokuapp.com/hcgi/api/health
```
→ Erwartet: `{"status":"ok"}` oder ähnlich

### 2. Status-Check
```bash
curl https://ce-translator.herokuapp.com/hcgi/api/status
```
→ Zeigt detaillierte Informationen über den Server

### 3. Übersetzung testen
```bash
curl -X POST https://ce-translator.herokuapp.com/hcgi/api/translate \
  -H "Content-Type: application/json" \
  -H "X-Requested-With: XMLHttpRequest" \
  -d '{"text":"Hello","sourceLanguage":"auto","targetLanguage":"de","targetLanguageName":"German"}'
```
→ Erwartet: `{"translatedText":"Hallo",...}`

### 4. App im Browser testen
- Öffne `https://ce-translator.herokuapp.com`
- Gib einen Text ein und übersetze ihn
- Teste die Spracheingabe und -ausgabe

---

## PocketBase (Datenbank) auf Heroku

> ⚠️ **Wichtiger Hinweis:** PocketBase (die eingebettete Datenbank) funktioniert auf Heroku **eingeschränkt**.
> Heroku hat ein **kurzlebiges Dateisystem** – Daten werden bei jedem Neustart gelöscht.

### Was bedeutet das für CE Translator?
- Die **Übersetzungsfunktion** funktioniert vollständig ohne Datenbank
- Der **Verlauf** wird im Browser-LocalStorage gespeichert (nicht auf dem Server)
- **Foto-Upload** funktioniert (Bilder werden nur im Arbeitsspeicher verarbeitet)

### Wenn du eine persistente Datenbank benötigst:

**Option A: PostgreSQL auf Heroku (empfohlen)**
```bash
heroku addons:create heroku-postgresql:mini
```
→ Kostet ca. $5/Monat. Erfordert Anpassung des Backends.

**Option B: PocketBase Cloud**
- Registriere dich unter https://pocketbase.io
- Nutze PocketBase als externen Dienst
- Setze die PocketBase-URL als Umgebungsvariable

**Option C: Fly.io für PocketBase**
- Deploye PocketBase separat auf https://fly.io (hat kostenlosen Tier)
- Volumen-Storage für persistente Daten

Für die Basisnutzung von CE Translator ist **keine Datenbank nötig**.

---

## Logs anzeigen (Fehlerdiagnose)

```bash
# Live-Logs anzeigen
heroku logs --tail

# Letzte 100 Zeilen
heroku logs -n 100
```

---

## Häufige Probleme

### Problem: "Application Error" nach dem Deploy
```bash
heroku logs --tail
```
→ Schaue in den Logs nach dem Fehler.

**Häufige Ursachen:**
- `INTEGRATED_AI_API_KEY` nicht gesetzt → `heroku config:set INTEGRATED_AI_API_KEY=sk-...`
- Build-Fehler → `heroku logs --tail` und Fehlermeldung lesen
- Port-Problem → Heroku setzt `PORT` automatisch; unser Server liest es korrekt

### Problem: Übersetzung funktioniert nicht
- Prüfe deinen OpenAI API-Key: https://platform.openai.com/usage
- Stelle sicher, dass Guthaben auf deinem OpenAI-Konto vorhanden ist
- Führe den Test-Curl-Befehl aus (Schritt 8)

### Problem: App schläft ein (free tier)
Heroku's kostenloser Tier „schläft" nach 30 Minuten Inaktivität.  
Die erste Anfrage nach dem Schlaf dauert ~5–10 Sekunden.  
→ **Lösung:** Upgrade auf Heroku Basic ($7/Monat) für Always-On.

---

## Alle Umgebungsvariablen (Übersicht)

| Variable | Beschreibung | Erforderlich | Beispiel |
|----------|-------------|--------------|---------|
| `INTEGRATED_AI_API_KEY` | OpenAI API-Key | ✅ Ja | `sk-abc123...` |
| `INTEGRATED_AI_API_URL` | OpenAI API URL | ✅ Ja | `https://api.openai.com/v1` |
| `OPENAI_TTS_MODEL` | TTS-Modell | Optional | `tts-1` |
| `CORS_ORIGIN` | Deine App-URL | ✅ Ja | `https://meine-app.herokuapp.com` |
| `NODE_ENV` | Umgebung | ✅ Ja | `production` |
| `PORT` | Port (automatisch von Heroku) | ❌ Nicht setzen | (automatisch) |

---

## App aktualisieren

Nach Codeänderungen einfach:
```bash
git add .
git commit -m "Beschreibung der Änderung"
git push heroku main
```

---

## Nützliche Heroku-Befehle

```bash
heroku open              # App im Browser öffnen
heroku logs --tail       # Live-Logs
heroku config            # Alle Variablen anzeigen
heroku ps                # Prozesse anzeigen
heroku restart           # Server neu starten
heroku run bash          # Terminal auf dem Server öffnen
```

---

*Erstellt für CE Translator – KI-Übersetzungs-App*
